#include <stdio.h>
#include <string.h>

void secure_function(char *input) {
    char buffer[50];
    // Secure: Use strncpy to avoid buffer overflow
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\0';  // Ensure null termination
    printf("You entered: %s\n", buffer);
}

int main() {
    char user_input[100];
    printf("Enter some text: ");
    fgets(user_input, sizeof(user_input), stdin);
    
    // Remove newline character from fgets input
    size_t len = strlen(user_input);
    if (len > 0 && user_input[len-1] == '\n') {
        user_input[len-1] = '\0';
    }

    secure_function(user_input);
    return 0;
}
