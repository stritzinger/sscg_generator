#include <stdio.h>
#include <stdlib.h>

int main() {
    int *ptr = (int*)malloc(sizeof(int) * 10);
    if (ptr == NULL) {
        return -1;
    }

    // Vulnerability: Forgetting to free memory (memory leak)
    return 0;
}
