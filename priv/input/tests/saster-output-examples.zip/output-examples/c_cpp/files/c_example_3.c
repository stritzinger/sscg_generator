#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void process_input(const char *input) {
    char *buffer = (char *)malloc(20 * sizeof(char));

    if (buffer == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }

    strcpy(buffer, input);  // Copy input to allocated buffer

    // Mistakenly free buffer early
    free(buffer);

    // Use buffer after it was freed - use-after-free vulnerability
    printf("Processed input: %s\n", buffer);

    // The buffer is already freed, but trying to free again
    free(buffer);  // Double free vulnerability
}

int main() {
    char input[50];
    printf("Enter some text: ");
    fgets(input, sizeof(input), stdin);

    // Trimming newline character
    input[strcspn(input, "\n")] = 0;

    process_input(input);
    return 0;
}
