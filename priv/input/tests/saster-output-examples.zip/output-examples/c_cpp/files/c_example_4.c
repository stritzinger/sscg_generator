#include "vulnerable.h"

// Function to initialize data, but missing size validation
void initialize_data(Data *data, int size) {
    // Subtle integer overflow vulnerability
    if (size > 0 && size < MAX_BUFFER_SIZE) {
        data->size = size * sizeof(char);  // Vulnerable multiplication
        data->buffer = (char *)malloc(data->size);
        if (data->buffer != NULL) {
            memset(data->buffer, 0, data->size);
        } else {
            printf("Memory allocation failed.\n");
        }
    } else {
        printf("Invalid size provided.\n");
    }
}

// Function that uses uninitialized buffer in some cases
void process_data(Data *data) {
    if (data->buffer) {
        printf("Processing data of size: %d\n", data->size);
        // Simulate processing
    } else {
        printf("Buffer is not initialized, using fallback.\n");
        char fallback[50];
        strcpy(fallback, "Default Data");
        printf("Processed: %s\n", fallback);  // Use of fallback without proper initialization
    }
}

// Proper cleanup function
void cleanup_data(Data *data) {
    if (data->buffer != NULL) {
        free(data->buffer);
        data->buffer = NULL;
    }
}

int main() {
    Data data;
    initialize_data(&data, -1);  // Test with invalid size to trigger subtle issue
    process_data(&data);
    cleanup_data(&data);
    return 0;
}
