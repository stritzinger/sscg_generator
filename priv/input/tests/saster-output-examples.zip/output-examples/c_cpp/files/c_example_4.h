#ifndef VULNERABLE_H
#define VULNERABLE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_BUFFER_SIZE 1024

typedef struct {
    int size;
    char *buffer;
} Data;

void initialize_data(Data *data, int size);
void process_data(Data *data);
void cleanup_data(Data *data);

#endif
