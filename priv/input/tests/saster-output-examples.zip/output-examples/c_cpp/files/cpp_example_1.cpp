#include <iostream>
#include <cstring>

void useAfterFree() {
    char* buffer = new char[50];
    std::strcpy(buffer, "This is a test string.");
    std::cout << "Buffer contains: " << buffer << std::endl;
    
    delete[] buffer; // Freeing the memory
    // Use-after-free vulnerability
    std::cout << "Buffer after delete: " << buffer << std::endl;

    // Simulate further use-after-free by modifying the freed memory
    std::strcpy(buffer, "This will cause undefined behavior.");
    std::cout << "Buffer contains after modification: " << buffer << std::endl;
}

int main() {
    useAfterFree();
    return 0;
}
