#include <iostream>
#include <memory>

class Resource {
public:
    Resource() { std::cout << "Resource acquired\n"; }
    ~Resource() { std::cout << "Resource destroyed\n"; }
};

void use_resource(bool trigger_exception) {
    std::unique_ptr<Resource> resource = std::make_unique<Resource>();

    if (trigger_exception) {
        throw std::runtime_error("Exception triggered!");
    }
    // Vulnerability: Resource is automatically freed when function exits
}

int main() {
    try {
        use_resource(true);  // Trigger exception here
    } catch (const std::exception &e) {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }

    std::cout << "Program ended\n";
    return 0;
}
