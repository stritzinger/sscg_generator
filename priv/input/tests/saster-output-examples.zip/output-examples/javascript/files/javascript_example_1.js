const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3000;

// Create connection to the database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'testdb'
});

// Connect to the database
db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('MySQL Connected...');
});

// Basic route for demonstration
app.get('/', (req, res) => {
  res.send('Welcome to the vulnerable app');
});

// Route with SQL Injection vulnerability
app.get('/user', (req, res) => {
  let userId = req.query.id;
  let sql = `SELECT * FROM users WHERE id = ${userId}`;

  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send(result);
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
