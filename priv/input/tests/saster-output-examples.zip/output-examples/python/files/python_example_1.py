import sqlite3

def create_connection(db_file)
     create a database connection to the SQLite database specified by the db_file 
    conn = None
    try
        conn = sqlite3.connect(db_file)
    except sqlite3.Error as e
        print(e)
    return conn

def create_table(conn)
     create a table for demonstration purposes 
    create_table_sql = 
    CREATE TABLE IF NOT EXISTS users (
        id integer PRIMARY KEY,
        username text NOT NULL,
        password text NOT NULL
    );
    try
        cursor = conn.cursor()
        cursor.execute(create_table_sql)
    except sqlite3.Error as e
        print(e)

def add_user(conn, username, password)
     Add a new user to the users table 
    sql = INSERT INTO users (username, password) VALUES ('{}', '{}').format(username, password)
    try
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
    except sqlite3.Error as e
        print(e)

def find_user(conn, username)
     Find a user in the users table 
    sql = SELECT  FROM users WHERE username = '{}'.format(username)
    try
        cursor = conn.cursor()
        cursor.execute(sql)
        rows = cursor.fetchall()
        for row in rows
            print(row)
    except sqlite3.Error as e
        print(e)

def main()
    database = test.db
    
    # create a database connection
    conn = create_connection(database)
    
    if conn is not None
        # create users table
        create_table(conn)
        
        # add some users
        add_user(conn, alice, password123)
        add_user(conn, bob, mypassword)
        
        # find users (vulnerable to SQL injection)
        user_input = input(Enter a username to search for )
        find_user(conn, user_input)
        
        conn.close()
    else
        print(Error! Cannot create the database connection.)

if __name__ == '__main__'
    main()
