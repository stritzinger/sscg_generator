import subprocess

def list_files(directory):
    """List files in the given directory"""
    try:
        # WARNING: Vulnerable to command injection
        command = "ls {}".format(directory)
        result = subprocess.check_output(command, shell=True)
        print(result.decode())
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")

def main():
    user_input = input("Enter the directory to list files: ")
    list_files(user_input)

if __name__ == "__main__":
    main()
