from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# Initialize the SQLite database
def init_db():
    conn = sqlite3.connect('test.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Route to demonstrate SQL injection vulnerability
@app.route('/vulnerable', methods=['GET'])
def vulnerable():
    username = request.args.get('username')
    query = f"SELECT * FROM users WHERE username = '{username}'"
    
    conn = sqlite3.connect('test.db')
    cursor = conn.cursor()
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    
    return jsonify(rows)

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
