import subprocess
import os
import hashlib
import pickle

# Vulnerability: Use of subprocess with user input (command injection)
def dangerous_function(user_input):
    subprocess.call(user_input, shell=True)

# Vulnerability: Use of MD5 for hashing (weak hashing algorithm)
def weak_hash(password):
    return hashlib.md5(password.encode('utf-8')).hexdigest()

# Vulnerability: Hardcoded secret key
SECRET_KEY = "my_secret_key"

# Vulnerability: Use of insecure pickle module (deserialization vuln)
def insecure_deserialization(data):
    return pickle.loads(data)

# Vulnerability: Environment variable injection
def load_from_env():
    secret = os.getenv("SECRET_ENV", "default_secret")
    print(f"Loaded secret: {secret}")

# Example usage of the vulnerable functions
if __name__ == "__main__":
    user_input = input("Enter a command: ")
    dangerous_function(user_input)

    password = input("Enter a password: ")
    print(f"Weak hash of your password: {weak_hash(password)}")

    data = pickle.dumps({"key": "value"})
    insecure_deserialization(data)

    load_from_env()