import jwt
import os
import json
import requests

# Vulnerability: Insecure use of JWT without verification
def decode_jwt(token):
    return jwt.decode(token, options={"verify_signature": False})

# Vulnerability: Hardcoded sensitive information
API_KEY = "12345-ABCDE-SECRET"

# Vulnerability: Sending sensitive data over HTTP
def send_data(data):
    response = requests.post("http://insecure-server.com/api/data", json=data)
    return response

# Vulnerability: Reading sensitive information from a file
def read_sensitive_file():
    with open("sensitive_info.txt", "r") as file:
        return file.read()

# Example usage of the vulnerable functions
if __name__ == "__main__":
    token = input("Enter JWT: ")
    print(f"Decoded token: {decode_jwt(token)}")

    data = {"username": "admin", "password": "admin123"}
    print(f"Response: {send_data(data)}")

    print(f"Sensitive file content: {read_sensitive_file()}")